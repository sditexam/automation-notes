package pages;

public class HyundaiCarPage {

}
